const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const PORT = 8765;
const KEY_FILE = path.join(process.env.HOME, '.cashbot', 'vultr_key.env');

function getKey() {
  try {
    const content = fs.readFileSync(KEY_FILE, 'utf8');
    const match = content.match(/VULTR_API_KEY=(.+)/);
    return match ? match[1].trim() : null;
  } catch(e) { return null; }
}

const CREDS_FILE = path.join(process.env.HOME, '.cashbot', 'credentials.env');

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }

  if (req.method === 'POST' && req.url === '/save-credentials') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const lines = Object.entries(data).map(([k, v]) => `${k}=${v}`).join('\n');
        fs.mkdirSync(path.dirname(CREDS_FILE), { recursive: true });
        fs.writeFileSync(CREDS_FILE, lines + '\n', 'utf8');
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, path: CREDS_FILE }));
      } catch(e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  if (req.url === '/credentials') {
    const CRED_FILE = path.join(process.env.HOME, '.cashbot', 'vultr-windows-vps-cashbot.txt');
    try {
      const content = fs.readFileSync(CRED_FILE, 'utf8');
      const ip   = (content.match(/^ip\s*:\s*(\S+)/im) || [])[1];
      const pass = (content.match(/^password\s*:\s*(\S+)/im) || [])[1];
      const user = (content.match(/^username\s*:\s*(\S+)/im) || [])[1] || 'Administrator';
      if (ip && pass) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ip, pass, user }));
      } else {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Could not parse credentials from file' }));
      }
    } catch(e) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'File not found: ' + CRED_FILE }));
    }
    return;
  }

  if (req.url !== '/instances') { res.writeHead(404); res.end('Not found'); return; }

  const key = getKey();
  if (!key) {
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'No Vultr API key found at ' + KEY_FILE + ' — complete Step B first' }));
    return;
  }

  const options = {
    hostname: 'api.vultr.com',
    path: '/v2/instances',
    method: 'GET',
    headers: { 'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json' }
  };

  const proxy = https.request(options, (apiRes) => {
    let data = '';
    apiRes.on('data', chunk => data += chunk);
    apiRes.on('end', () => {
      res.writeHead(apiRes.statusCode, { 'Content-Type': 'application/json' });
      res.end(data);
    });
  });
  proxy.on('error', (e) => {
    res.writeHead(502, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: e.message }));
  });
  proxy.end();
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  Vultr proxy ready at http://localhost:' + PORT);
  console.log('  Reading API key from: ' + KEY_FILE);
  console.log('  Go to phase2-setup.html and click "PULL SERVERS FROM VULTR API"');
  console.log('  Press Ctrl+C to stop');
  console.log('');
});
